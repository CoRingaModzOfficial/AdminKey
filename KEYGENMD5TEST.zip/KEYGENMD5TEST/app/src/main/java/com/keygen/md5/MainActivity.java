package com.keygen.md5;
 
import android.app.Activity;
import android.widget.EditText;
import android.widget.Button;
import android.widget.LinearLayout;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity {


    private EditText edittext1;
    private Button button1;
    private LinearLayout linear1;
    private Button button2;

    private AlertDialog.Builder copy;
    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize(_savedInstanceState);
        initializeLogic();
    }

    private void initialize(Bundle _savedInstanceState) {

        edittext1 = (EditText) findViewById(R.id.edittext1);
        button1 = (Button) findViewById(R.id.button1);
        linear1 = (LinearLayout) findViewById(R.id.linear1);
        button2 = (Button) findViewById(R.id.button2);
        copy = new AlertDialog.Builder(this);

        button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    if (edittext1.getText().toString().contains("e")) {
                        edittext1.setText(edittext1.getText().toString().replace("e", "E"));
                        edittext1.setText(edittext1.getText().toString().replace("d", "D"));
                        edittext1.setText(edittext1.getText().toString().replace("b", "B"));
                        edittext1.setText(edittext1.getText().toString().replace("9", "98"));
                        edittext1.setText(edittext1.getText().toString().replace("100", "8H"));
                        edittext1.setText(edittext1.getText().toString().replace("4", "4DD"));
                        edittext1.setText(edittext1.getText().toString().replace("5", "5DB"));
                        edittext1.setText(edittext1.getText().toString().replace("6", "6DHBFT"));
                        edittext1.setText(edittext1.getText().toString().replace("f", "FF"));
                        edittext1.setText(edittext1.getText().toString().replace("h", "H5"));
                        edittext1.setText(edittext1.getText().toString().replace("f", "FF5"));
                        edittext1.setText(edittext1.getText().toString().replace("0", "0DH"));
                        edittext1.setText(edittext1.getText().toString().replace("c", "CCH5"));
                        edittext1.setText(edittext1.getText().toString().replace("8", "558H"));
                        edittext1.setText(edittext1.getText().toString().replace("M", "MD5"));
                        edittext1.setText(edittext1.getText().toString().replace("65", "6MD4"));
                        edittext1.setText(edittext1.getText().toString().replace("2", "H2D"));
                        edittext1.setText(edittext1.getText().toString().replace("3", "55DB"));
                        edittext1.setText(edittext1.getText().toString().replace("a", "MB40"));
                        
                    }
                }
            });

        button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    copy.setTitle("You - Key");
                    copy.setMessage(edittext1.getText().toString());
                    copy.setPositiveButton("COPY", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface _dialog, int _which) {
                                ((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", edittext1.getText().toString()));
                              Toast.makeText(getApplicationContext(), "Copiada!!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    copy.create().show();
                }
            });
    }
    private void initializeLogic() {
    }

}

